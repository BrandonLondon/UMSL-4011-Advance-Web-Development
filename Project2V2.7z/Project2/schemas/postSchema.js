const mongoose = require("mongoose");

const PostSchema = mongoose.model("Posts", {
    userId: {type: mongoose.Types.ObjectId, required: true, ref: "Users"},
    id: {type: Number, required: true},
    title: {type: String, required: true},
    body: {type: String, required: true},
});

module.exports = PostSchema;