const mongoose = require("mongoose");

const UserSchema = mongoose.model("Users",{
    id: {type: Number, unique: true, required: true},
    name: {type: String, required: true},
    username: {type: String, required: true},
    email: {type: String, unique: true, required: true},
    phone: {type: String, required: true},
    website: {type: String, required: true},
    company: {
        name: {type: String, required: true},
        catchPhrase: {type: String, required: true},
        bs: {type: String, required: true}
    }
});

module.exports = UserSchema;