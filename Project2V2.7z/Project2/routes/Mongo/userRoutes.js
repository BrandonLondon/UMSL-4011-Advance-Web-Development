const express = require("express");
const mongoose = require("mongoose");
const UserSchema = require("../../schemas/userSchema");
const mongoURL = "mongodb://127.0.0.1:27017/dataTest";


const addUsers = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
        const user = new UserSchema(req.body);
        const result = await user.save();
        mongoose.disconnect();

        res.send(result);
    } catch (error) {
        console.error(error);
        res.status(500);
        res.send(error);
    }
    
};


const getUser = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
        const results = await UserSchema.find({
            username: req.params.username,
        }).exec();
        mongoose.disconnect();

        res.send(results);
    } catch (error) {
        console.error("error", error);
        res.status(500);
        res.send(error);
    }
};



const updateUsers = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
    
        const id = req.params.id;
        const user = await UserSchema.findById(id).exec();
        user.set(req.body);
        const result = await user.save();
        mongoose.disconnect();
    
        res.send(result);
      } catch (error) {
        console.error("error", error);
        res.status(500);
        res.send(error);
      }
};

const removeUser = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
        const id = req.params.id;
        const result = await UserSchema.deleteOne({ id: id }).exec();
        mongoose.disconnect();
    
        res.send(result);
    } catch (error) {
        console.error("error", error);
        res.status(500);
        res.send(error);
    }
};

const userRouter = express.Router();

userRouter
    .post("/", addUsers);

userRouter
    .route("/:id")
    .put(updateUsers)
    .delete(removeUser);


userRouter.route("/profile/:username").get(getUser);

module.exports = userRouter ;