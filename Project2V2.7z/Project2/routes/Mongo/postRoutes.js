const express = require("express");
const mongoose = require("mongoose");
const Users = require("../../schemas/userSchema");
const PostSchema = require("../../schemas/postSchema");

const mongoURL = "mongodb://127.0.0.1:27017/dataTest";

const getEveryPost = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
        const results = await PostSchema.find();
        mongoose.disconnect();
    
        res.send(results);
    } catch (error) {
        console.error("error", error);
        res.status(500);
        res.send(error);
    }
};

const getPostbyUser = async (req, res) => {
    username = req.params.username;
    let user 
    try {
        mongoose.connect(mongoURL);
        user = await Users.find({ "username" : username });
    }
    catch{
        console.error(error);
        res.status(500);
        mongoose.disconnect();
        res.send(error);
    }
    if (!user) {
        res.status(404);
        res.send();
    }
    console.log(user);
    try{
        posts = await PostSchema.find({ "userId" : user[0]._id });
        mongoose.disconnect();
        res.send(posts);
    }catch(error){
        console.error(error);
        res.status(500);
        res.send(error);
    }

}
const addUsersPost = async (req, res) => {
    const { userId, title, body, id } = req.body;
    let user 
    try {
        mongoose.connect(mongoURL);
        user = await Users.find({ "id" : userId });
    }
    catch{
        console.error(error);
        res.status(500);
        mongoose.disconnect();
        res.send(error);
    }
    if (!user) {
        res.status(404);
        res.send();
    }
    const post = new PostSchema({
        title, body, id, userId: user[0]._id
    });
    try {
        await post.save();
        mongoose.disconnect();

        res.send(post);
    } catch (error) {
        console.error(error);
        res.status(500);
        res.send(error);
    }
};
const updateUserPost = async (req, res) => {
    const { title, body} = req.body;
    let post 
    try {
        mongoose.connect(mongoURL);
        post = await PostSchema.findOne({ "id" : req.params.postid });
        post.title = title;
        post.body = body;
        
        res.send(post)
    }
    catch{
        console.error(error);
        res.status(500);
        res.send(error);
    }
    try{
        await post.save();
        mongoose.disconnect();
    } catch {
        console.error(error);
        res.status(500);
        res.send(error);
    }
}
const removePosts = async (req, res) => {
    try {
        mongoose.connect(mongoURL);
        const id = req.params.postsid;
        const result = await PostSchema.deleteOne({ id: id }).exec();
        mongoose.disconnect();
    
        res.send(result);
    } catch (error) {
        console.error("error", error);
        res.status(500);
        res.send(error);
    }
};
const getPostbyId = async (req, res) => {
    let postId
    postId = req.params.postids;
        try {
            mongoose.connect(mongoURL);
            const results = await PostSchema.find({ "id" : postId});
            mongoose.disconnect();
        
            res.send(results);
        } catch (error) {
            console.error("error", error);
            res.status(500);
            res.send(error);
        }
    
};

const postRouter = express.Router();

postRouter
    .route("/")
    .post(addUsersPost)
    .get(getEveryPost);
postRouter.route("/allPosts/:username").get(getPostbyUser);
postRouter.route("/:postid").patch(updateUserPost);
postRouter.route("/:postsid").delete(removePosts);
postRouter.route("/:postids").get(getPostbyId);
module.exports = postRouter;