const fizzbuzz = (count) => {
    if (count % 3 === 0 && count % 5 === 0) {
        return "fizzbuzz";
    } else if (count % 3 === 0) {
        return "fizz";
    } else if (count % 5 === 0) {
        return "buzz";
    } else {
        return count;
    }
};

const fizzBuzzArray = (count) => {
    const array_set = [];
    for (var i = 1; i <= count; i++) {
        array_set.push(fizzbuzz(i));
    }
    return array_set;
};

module.exports.fizzbuzz = fizzbuzz;
module.exports.fizzBuzzArray = fizzBuzzArray;
