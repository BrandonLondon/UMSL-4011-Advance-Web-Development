const normalize = (name) => {
    if (name == "") {
        return name;
    }
    const commas = name.match(/,/g);
    if (commas && commas.length > 1) {
        throw null;
    }

    const new_name = name.trim().replace(",", "").split(" ");
    switch (new_name.length) {
        case 1:
            return name;

        case 2:
            return `${new_name[1]}, ${new_name[0]}`;

        case 3:
            if (new_name[1].length == 1) {
                return `${new_name[2]}, ${new_name[0]} ${new_name[1]}`;
            }
            return `${new_name[2]}, ${new_name[0]} ${new_name[1][0]}.`;

        case 4:
            if (new_name[3].indexOf(".") !== -1) {
                return `${new_name[2]}, ${new_name[0]} ${new_name[1][0]}., ${new_name[3]}`;
            }
            return `${new_name[3]}, ${new_name[0]} ${new_name[1][0]}. ${new_name[2][0]}.`;

        default:
            return name;
    }
};

module.exports = normalize;
