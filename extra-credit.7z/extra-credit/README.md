## Testing!

This testing project is using Jest and ES6


To run this code, type: 

```
npm install
npm run test
```

In order to keep the tests running as you code: 
```
npm run test:watch
```