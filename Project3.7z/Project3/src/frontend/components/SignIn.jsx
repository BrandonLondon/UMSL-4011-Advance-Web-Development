import Cookies from 'universal-cookie';
import React, {useState} from 'react'
import {Image, Icon, Button, Form} from 'semantic-ui-react'
import {Redirect} from 'react-router-dom';
import agent from "./util/agent"

export default function SignIn() {
    const [password, setPassword] = useState("");
    const [username, setUsername] = useState("");
    const [incorrect, setIncorrect] = useState(false);
    const [isloggedIn, setLoggedIn] = useState(false);
    const helperLogin = async () => {
        try{
            const response = await agent.post("/tokens", {username, password})
            const cookies = new Cookies();
            cookies.set('token',response);
            const token = await cookies.get('token');
            console.log("repsonse",response)
            setLoggedIn(true)
        }catch(error) {
            setIncorrect(true)
        }


    }
    const setPasswordHelper = (event) => {
        setIncorrect(false)
        setPassword(event.target.value)

    }
    const setUsernameHelper = (event) => {
        setIncorrect(false)
        setUsername(event.target.value)
    }
    return (
        <>
        <p>
            Please sign in:
            {incorrect && <div>Stop kidding around</div>}
        </p>
        <Form>
            <Form.Field>
                <label>Username</label>
                <input type="text" required='yes' value={username} onChange={setUsernameHelper}/>
            </Form.Field>
            <Form.Field>
                <label>Password</label>
                <input type="text" type='password' required='yes' value={password} onChange={setPasswordHelper}/>
            </Form.Field>
                    <Button animated inverted color='red' onClick={helperLogin}>
                        <Button.Content visible>Sign In and Sell your soul</Button.Content>
                        <Button.Content hidden>
                            <Icon name='arrow right' />
                        </Button.Content>
                    </Button>
                <Image src = 'https://media.giphy.com/media/ZtB2l3jHiJsFa/giphy.gif' size='huge'/>
        </Form>
        {isloggedIn && <Redirect to="/"/>}
        </>
        
    )
}