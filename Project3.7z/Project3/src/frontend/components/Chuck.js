import React from 'react'
import {Image, Card, Grid, Segment} from 'semantic-ui-react';

export default function Chuck({results}) {
    return (
        <>
        {results.map((chuck, key) => {
            return (
                <>
                { <Grid.Column key={key}>
                    <Segment >
                        <Card fluid>
                            <Card.Content>
                                <Card.Header>
                                    Chuck Norris quote:
                                </Card.Header>
                                <Card.Description>
                                    <span>
                                    {chuck.value}
                                    </span>
                                </Card.Description>
                                
                            </Card.Content>
                        </Card>
                        <Image src = 'https://media.giphy.com/media/ChX3hzy5CkXsI/giphy.gif' size='huge'/>
                    </Segment>
                </Grid.Column> }
                </>
            );
        })}
        </>
);
}