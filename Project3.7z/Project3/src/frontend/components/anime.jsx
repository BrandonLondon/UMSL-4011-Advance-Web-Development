import React from 'react'
import {Image, Card, Grid, Segment, CardDescription} from 'semantic-ui-react';
import getAllCharacters from './helpers/animeHelper';

export default function Anime({results}) {
    
    getAllCharacters()
    return (
        <>
        {results.map((anime, key) => {
            return (
                <>
                { <Grid.Column key={key}>
                    <Segment >
                        <Card fluid>
                            <Card.Content>
                                <Card.Header>
                                    Anime: {anime.data[1].attributes.name}
                                </Card.Header>
                                <CardDescription>
                                    {anime.data[1].attributes.description}
                                </CardDescription>
                            </Card.Content>
                        </Card>
                    </Segment>
                </Grid.Column> }
                <Image src = 'https://media.giphy.com/media/J4U7OGjl37eybL38vi/giphy.gif' size='large'/>
                </>
            );
        })}
        </>
    );
}