
import React from 'react'
import {Image, Icon, Button} from 'semantic-ui-react'
import {Link} from 'react-router-dom';

export default function Home() {
    return (
        <div>
            <h2>Welcome to the THUNDERDOME!</h2>
            <p>
            <Link to = '/sign-up'>
                <Button animated inverted color='blue'>
                    <Button.Content visible>Have you signed up?</Button.Content>
                    <Button.Content hidden>
                        <Icon name='pencil alternate' on='click'/>
                        
                    </Button.Content>
                </Button>
            </Link>
            <Link to = '/sign-in'>
                <Button animated inverted color='blue'>
                    <Button.Content visible>Sign in</Button.Content>
                    <Button.Content hidden>
                        <Icon name='hand point right outline' />
                        
                    </Button.Content>
                </Button>
            </Link>
            <Image src = 'https://media.giphy.com/media/Y01jP8QeLOox2/giphy.gif' size='huge'/>
            </p>
        </div>
    )
}