import React from 'react'
import {Image, Icon, Button, Form} from 'semantic-ui-react'
import {Link} from 'react-router-dom';

export default function SignUp() {
    return (
    <>
            <p>
                Please create an account:
            </p>
            
            <Form>
                <Form.Field>
                    <label>Username</label>
                    <input placeholder='username' required='yes' />
                </Form.Field>
                <Form.Field>
                    <label>Password</label>
                    <input placeholder='password' type='password' required='yes' />
                </Form.Field>
                <Link to = '/'>
                        <Button animated inverted color='green' onClick={Link.apply}>
                            <Button.Content visible>Sign up</Button.Content>
                            <Button.Content hidden>
                                <Icon name='arrow right' />
                                
                            </Button.Content>
                        </Button>
                    </Link>
                    <Image src = 'https://media.giphy.com/media/VDYBzzxF4mrE0gsRbT/giphy.gif' size='huge'/>
            </Form>
            
        </>
    )
}