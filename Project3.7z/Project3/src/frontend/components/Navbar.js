import React from 'react';
import {Menu, Container} from 'semantic-ui-react';
import {Link} from 'react-router-dom';

export default function Navbar() {
    return (
        <Menu inverted>
            <Container>
                
                <Link to = '/'>
                    <Menu.Item name="Project 3"/>
                </Link>
                <Link to = '/anime'>
                    <Menu.Item name="Anime (O^w^O)"/>
                </Link>
                <Link to = '/chucknorris'>
                    <Menu.Item name="Chuck Norris"/>
                </Link>
            </Container>
        </Menu>
    );
}