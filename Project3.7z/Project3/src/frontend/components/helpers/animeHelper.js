import Cookies from 'universal-cookie';
import agent from '../util/agent';

const url = 'http://localhost:5000/anime';


const getAllCharacters = async (setCharacters) => {
  try {
    // Get characters from backend
    const cookies = new Cookies();
    const token = cookies.get('token');
    console.log('Tokens YEAAHHHHH', token);
    const animeCharacters = await agent.get("/anime", { Authorization: `Bearer ${token}` });
    console.log("anime bitches", animeCharacters)
    const parsedChars = await JSON.parse(animeCharacters.text);
    console.log("parsed Chars please exist", parsedChars);

    return parsedChars;
  } catch (error) {
    console.error(error);
  }
};


export default getAllCharacters;