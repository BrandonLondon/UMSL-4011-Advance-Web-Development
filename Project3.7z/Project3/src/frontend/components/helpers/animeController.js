const animeHelper = require('./animeHelper');

const getAllCharacters = async (req, res) => {
  try {
    const response = await animeHelper.getAllCharacters();


    console.log('response', response);
    res.send(response);
  } catch (error) {
    console.error(error);

    res.send(error);
  }
};


export default getAllCharacters;
