
import React, {useState, useEffect} from 'react';
import Navbar from "./components/Navbar";
import Home from './components/Home';
import Anime from './components/anime';
import Chuck from './components/Chuck';
import SignUp from './components/SignUp';
import SignIn from './components/SignIn';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import {Container} from 'semantic-ui-react';

function App() {
    const [anime, setAnime] = useState([]);
    const [chuck, setNorris] = useState([]);

    useEffect(() => {
        async function fetchChuckNorrisQuote() {
            let chuck_Norris_url = 'https://api.chucknorris.io/jokes/random';
            const page1 = [];
                let res = await fetch(chuck_Norris_url);
                let data = await res.json();
                //chuck_Norris_url = data.next;
                page1.push(data);
                setNorris(page1);
        }

        async function fetchAnimeGirls() {
            let anime_url = 'https://kitsu.io/api/edge/characters';
            const page2 = [];

           // do {
                let res = await fetch(anime_url);
                let data = await res.json();
                //anime_url = data.next;
                page2.push(data);
                setAnime(page2)
          //  }
           // while (anime_url);
        }
        fetchChuckNorrisQuote()
        fetchAnimeGirls()
    }, []);
    return (
        <>
      <Router>
        <Navbar />
        <Container>
            <Switch>
                <Route exact path = '/'>
                  <Home />
                </Route>
                <Route exact path = '/anime'>
                  <Anime results={anime}/>
                </Route>
                <Route exact path = '/chucknorris'>
                  <Chuck results={chuck}/>
                </Route>
                <Route exact path = '/sign-up'>
                  <SignUp />
                </Route>
                <Route exact path = '/sign-in'>
                  <SignIn />
                </Route>
          </Switch>
        </Container>
      </Router>
    </>
    );
}

export default App
