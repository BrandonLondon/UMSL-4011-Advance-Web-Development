const express = require('express');
const { getAllCharacters } = require('../../controller/anime/animeController');

const animeRouter = express.Router();

animeRouter.route('/').get(getAllCharacters);

module.exports = animeRouter;
