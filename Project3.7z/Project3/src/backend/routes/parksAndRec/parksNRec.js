module.exports = {
  'Leslie Knope': 'Amy Poehler',
  'Ann Perkins': 'Rashida Jones',
  'Mark Brendanawicz': 'Paul Schneider',
  'Tom Haverford': 'Aziz Ansari',
  'Ron Swanson': 'Nick Offerman',
  'April Ludgate': 'Aubrey Plaza',
  'Andy Dwyer': 'Chris Pratt',
  'Ben Wyatt': 'Adam Scott',
  'Chris Traeger': 'Rob Lowe',
  'Jerry Gergich': "Jim O'Heir",
  'Donna Meagle': 'Retta',
  'Craig Middlebrooks': 'Billy Eichner',
};
