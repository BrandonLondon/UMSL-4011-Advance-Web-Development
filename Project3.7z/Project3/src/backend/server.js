const mongoose = require('mongoose');
const express = require('express');
const swaggerUI = require('swagger-ui-express');
const swaggerDoc = require('./lib/swagger');
const { userRouter } = require('./routes/users/userServices');
const tokenRouter = require('./routes/users/tokens');
const animeRouter = require('./routes/anime/animeRoute');

const logger = require('./lib/middleware/logger');

const app = express();
const tokenAuth = require('./lib/middleware/tokenAuth');
const parksAndRecRouter = require('./routes/parksAndRec/parksAndRecRoute');


const mongoURL = 'mongodb://127.0.0.1:27017/anime';
mongoose.connect(mongoURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
});
const dbConnection = mongoose.connection;
dbConnection.on('error', (err) => console.error(err));
dbConnection.once('open', () => console.log('Connected to db'));

app.use(logger);
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerDoc));
app.use('/newUser', userRouter);
app.use('/tokens', tokenRouter);
app.use('/parksAndRec', parksAndRecRouter);

app.use(tokenAuth);
app.use('/anime', animeRouter);


const port = 5000;
app.listen(port, () => console.log('Now listening on port:', port));
console.log(`Swagger docs at localhost:${port}/api-docs`);
