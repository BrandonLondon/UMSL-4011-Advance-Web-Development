const agent = require('../../lib/agent');

const baseUrl = 'https://kitsu.io/api/edge';

const getAllCharacters = async () => {
  try {
    const response = await agent.get(`${baseUrl}/characters`, {}, {
      Authorization: 'Bearer 94b5462cf3e19f63812341d5c592dd05073254478b488d55804089476ad2b0a3',
    });


    const parsedResponseData = JSON.parse(response.text);
    const responseArray = parsedResponseData || [];
    return responseArray;
  } catch (error) {
    console.error('Error in getAllChars', error);
    return [];
  }
};


const getSpecificCharacter = async (characterName) => {
  const allCharacters = await getAllCharacters();

  const specificCharacter = allCharacters.find((character) => character.name === characterName) || { message: 'No character found' };

  if (specificCharacter.message) {
    throw new Error('Nooooooooo');
  }

  return specificCharacter;
};


module.exports = {
  getAllCharacters,
  getSpecificCharacter,
};
