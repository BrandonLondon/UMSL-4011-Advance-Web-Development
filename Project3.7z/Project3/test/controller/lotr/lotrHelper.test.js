const { getAllCharacters } = require('../../../src/controller/lotr/lotrHelper');


describe('Lotr Helper Functions', () => {
  it('makes call to the one api and returns all character data', async () => {
    const expected = [
      {
        _id: '5cd99d4bde30eff6ebccfdf3',
        height: '',
        race: 'Human',
        gender: 'Male',
        birth: 'SA 192',
        spouse: 'Unnamed wife',
        death: 'SA 603',
        realm: 'Númenor',
        hair: '',
        name: 'Tar-Amandil',
        wikiUrl: 'http://lotr.wikia.com//wiki/Tar-Amandil',
      },
    ];

    const actualResponse = await getAllCharacters();

    expected(actualResponse).toBe(expected);
  });
});
