const express = require("express");
const axios = require("axios");

const getPostsid = async (req, res) => {
    let postid = req.params.postid;
    let baseurl = `https://jsonplaceholder.typicode.com/posts/${postid}`;
    let jsonResult = [];

    try {
        const res = await axios.get(baseurl);
        jsonResult.push(res.data);
    } catch (err) {
        console.log(err);
    }

    res.send(jsonResult.flat());
};

const setPosts = (req, res) => {
    res.send(req.body);
};

const updatedPosts = (req,res) => {
    let id = req.params.id;
    res.send(req.body);
};

const deletePosts = (req, res ) => {
    let postid = req.params.postid;
    res.send(req.body);
};

const postsRouter = express.Router();
postsRouter.get("/:postid", getPostsid);
postsRouter.post("/", setPosts);
postsRouter.patch("/:id", updatedPosts);
postsRouter.delete("/:postid", deletePosts);

module.exports = postsRouter;