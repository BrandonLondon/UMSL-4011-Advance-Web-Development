const express = require("express");
const axios = require("axios");

const getUser = async (req, res) => {
    let userid = req.params.userid;
    let baseUrl = `https://jsonplaceholder.typicode.com/users?id=${userid}`;
    let jsonResult = [];

    try {
        const res = await axios.get(baseUrl);
        jsonResult.push(res.data);
    } catch(err) {
        console.log(err);
    }

    res.send(jsonResult.flat());
};

const profileRouter = express.Router();
profileRouter.get("/:userid", getUser);

module.exports = profileRouter;