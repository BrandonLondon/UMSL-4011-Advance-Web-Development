const express = require("express");
const axios = require("axios");

const getAllUserPosts = async (req, res) => {
    let userPosts = req.params.userPosts;
    let baseUrl = `https://jsonplaceholder.typicode.com/posts?userId=${userPosts}`;
    let jsonResult = [];

    try {
        const res = await axios.get(baseUrl);
        jsonResult.push(res.data);
    } catch(err) {
        console.log(err);
    }

    res.send(jsonResult.flat());
};

const allUserPostsRouter = express.Router();
allUserPostsRouter.get("/:userPosts", getAllUserPosts);

module.exports = allUserPostsRouter;