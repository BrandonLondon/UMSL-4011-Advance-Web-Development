const express = require("express");
const { parseJSON, urlencodedParser } = require("./lib/middleware/bodyParser");
const allPostsRouter = require("./routes/allPosts/allPostsRoute");
const postsRouter = require("./routes/posts/postsRoute");
const profileRouter = require("./routes/profile/profileRoute");

const allUserPostsRouter = require("./routes/allPosts/allUserPosts");

const logger = require('./lib/middleware/logger');
const swaggerUI = require("swagger-ui-express");
const swaggerDoc = require('./lib/middleware/swagger');

const app = express();
const port = 3000;

app.use(logger);

app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerDoc));
app.use(parseJSON, urlencodedParser);
app.use("/allPosts", allPostsRouter);
app.use("/allPosts", allUserPostsRouter);
app.use("/posts", postsRouter);
app.use("/profile", profileRouter);


app.listen(port, () => console.log(`App listening on port ${port}!`));